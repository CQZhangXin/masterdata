create PROCEDURE P_T_TO_C1_GROUP AS
  /*
	更新组  用于同步
	gky
	20190701
	*/

BEGIN

    --#####################################################  更新 T_TO_C1_GROUP 表
    EXECUTE IMMEDIATE 'TRUNCATE TABLE T_TO_C1_GROUP';
    INSERT INTO T_TO_C1_GROUP
		SELECT T.FENTITY_CODE,T.FENTITY_NAME,SYSDATE FROM T_TO_C1_ENTITY T ;
		COMMIT;
END;
/

